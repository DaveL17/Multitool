#! /usr/bin/env python2.6
# -*- coding: utf-8 -*-

# TODO: There is no way to initiate debug logging.  Setting it with a state variable for now.

try:
    import indigo
except ImportError, error:
    indigo.server.log(str(error))
try:
    import pydevd
except ImportError, error:
    indigo.server.log(str(error))


class Plugin(indigo.PluginBase):

    def __init__(self, pluginId, pluginDisplayName, pluginVersion, pluginPrefs):
        indigo.PluginBase.__init__(self, pluginId, pluginDisplayName, pluginVersion, pluginPrefs)

        self.error_msg_dict = indigo.Dict()

        self.debug = False

        # To enable remote PyCharm Debugging, uncomment the next line.
        # pydevd.settrace('localhost', port=5678, stdoutToServer=True, stderrToServer=True, suspend=False)

    def classToPrint(self, typeId, valuesDict):
        self.debugLog(u"classToPrint")


    def dictToPrint(self, typeId, valuesDict, targetId):
        self.debugLog(u"dictToPrint")

        if not valuesDict:
            return [("none", "None")]
        else:
            foo = valuesDict['classOfThing']
            return [(thing.id, thing.name) for thing in getattr(indigo, foo)]

    def resultsOutput(self, valuesDict, caller):

        thing = getattr(indigo, valuesDict['classOfThing'])[int(valuesDict['thingToPrint'])]
        indigo.server.log(u"\n*** {0} Dict ***\n{1}\n{2}".format(thing.name, thing, (u"*" * 20)))
        return True
