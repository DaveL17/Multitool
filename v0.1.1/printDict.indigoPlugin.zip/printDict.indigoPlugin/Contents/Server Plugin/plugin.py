#! /usr/bin/env python2.6
# -*- coding: utf-8 -*-

try:
    import indigo
except ImportError, error:
    indigo.server.log(str(error))
try:
    import pydevd
except ImportError, error:
    indigo.server.log(str(error))


class Plugin(indigo.PluginBase):

    def __init__(self, pluginId, pluginDisplayName, pluginVersion, pluginPrefs):
        indigo.PluginBase.__init__(self, pluginId, pluginDisplayName, pluginVersion, pluginPrefs)

        self.error_msg_dict = indigo.Dict()

        # To enable remote PyCharm Debugging, uncomment the next line.
        # pydevd.settrace('localhost', port=5678, stdoutToServer=True, stderrToServer=True, suspend=False)

    def customActionList(self, filter="indigo.actionGroups", typeId=0, valuesDict=None, targetId=0):
        self.debugLog(u"typeId = {0}, targetId = {1}".format(typeId, targetId))
        return [(action.id, action.name) for action in indigo.actionGroups.itervalues()]

    def customControlPageList(self, filter="indigo.controlPages", typeId=0, valuesDict=None, targetId=0):
        self.debugLog(u"typeId = {0}, targetId = {1}".format(typeId, targetId))
        return [(control_page.id, control_page.name) for control_page in indigo.controlPages.itervalues()]

    def customDeviceList(self, filter="indigo.devices", typeId=0, valuesDict=None, targetId=0):
        self.debugLog(u"typeId = {0}, targetId = {1}".format(typeId, targetId))
        return [(device.id, device.name) for device in indigo.devices.itervalues()]

    def customScheduleList(self, filter="indigo.schedules", typeId=0, valuesDict=None, targetId=0):
        self.debugLog(u"typeId = {0}, targetId = {1}".format(typeId, targetId))
        return [(schedule.id, schedule.name) for schedule in indigo.schedules.itervalues()]

    def customTriggerList(self, filter="indigo.triggers", typeId=0, valuesDict=None, targetId=0):
        self.debugLog(u"typeId = {0}, targetId = {1}".format(typeId, targetId))
        return [(trigger.id, trigger.name) for trigger in indigo.triggers.itervalues()]

    def customVariableList(self, filter="indigo.variables", typeId=0, valuesDict=None, targetId=0):
        self.debugLog(u"typeId = {0}, targetId = {1}".format(typeId, targetId))
        return [(variable.id, variable.name) for variable in indigo.variables.itervalues()]

    def customWriteAction(self, valuesDict, typeId):
        self.debugLog(u"{0}".format(typeId))
        try:
            self.resultsOutput(u"Action", indigo.actionGroups[int(valuesDict['indigoActionID'])])
        except:
            self.error_msg_dict['indigoActionID'] = u"You must select an action to execute. Select an action or click cancel."
            return False, valuesDict, self.error_msg_dict
        return True

    def customWriteControlPage(self, valuesDict, typeId):
        self.debugLog(u"{0}".format(typeId))
        try:
            self.resultsOutput(u"Control Page", indigo.controlPages[int(valuesDict['indigoControlPageID'])])
        except:
            self.error_msg_dict['indigoControlPageID'] = u"You must select a control page to execute. Select a control page or click cancel."
            return False, valuesDict, self.error_msg_dict
        return True

    def customWriteDevice(self, valuesDict, typeId):
        self.debugLog(u"{0}".format(typeId))
        try:
            self.resultsOutput(u"Device", indigo.devices[int(valuesDict['indigoDeviceID'])])
        except:
            self.error_msg_dict['indigoDeviceID'] = u"You must select a device to execute. Select a device or click cancel."
            return False, valuesDict, self.error_msg_dict
        return True

    def customWriteSchedule(self, valuesDict, typeId):
        self.debugLog(u"{0}".format(typeId))
        try:
            self.resultsOutput(u"Schedule", indigo.schedules[int(valuesDict['indigoScheduleID'])])
        except:
            self.error_msg_dict['indigoScheduleID'] = u"You must select a schedule to execute. Select a schedule or click cancel."
            return False, valuesDict, self.error_msg_dict
        return True

    def customWriteTrigger(self, valuesDict, typeId):
        self.debugLog(u"{0}".format(typeId))
        try:
            self.resultsOutput(u"Trigger", indigo.triggers[int(valuesDict['indigoTriggerID'])])
        except:
            self.error_msg_dict['indigoTriggerID'] = u"You must select a trigger to execute. Select a trigger or click cancel."
            return False, valuesDict, self.error_msg_dict
        return True

    def customWriteVariable(self, valuesDict, typeId):
        self.debugLog(u"{0}".format(typeId))
        try:
            self.resultsOutput(u"Variable", indigo.variables[int(valuesDict['indigoVariableID'])])
        except:
            self.error_msg_dict['indigoVariableID'] = u"You must select a variable to execute. Select a variable or click cancel."
            return False, valuesDict, self.error_msg_dict
        return True

    def resultsOutput(self, source, result):
        indigo.server.log(u"\n*** {0} Dict ***\n{1}\n{2}".format(source, result, (u"*" * 20)))
